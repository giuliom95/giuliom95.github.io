Version History:
 - 'Dana_Rig_v001'
 - 'Dana_Rig_v1.1.mb' - Fixed arms twist problem.
 - 'Dana_Rig_v1.2.mb' - Added 'Partial' and 'Full' body geometry options in Main controller. Fixed Head Squash and hip deformations.
 - 'Dana_Rig_v1.3.mb' - Added new controllers: the IK Spine has a controller between the root and chest; each finger has a new controller near the wrist to achieve smoother curves and archs with the fingers; the Scalpula controls have a 'Breast Drag' attribute that controls how much the scalpula movement affects the breasts (a value of 0.3 gives the best results in my opinion); and lastly breast controllers.


------------------
Remember to tag your posts on instagram with #DanaRig or #DavidRig!

Thanks to everyone who has rated this rig on Gumroad, it really helps to spread the word!

I made a twitter account to post updates for this project: https://twitter.com/gabrielsalas_
You can also find me on Artstation: 
https://www.artstation.com/gabrielsalas


------------------
Terms of use:

No racist, pornographic or otherwise offensive content.

Educational, non commercial use only. You are allowed to use these rigs on your animation reel or portfolio. To discuss commercial use please get in touch with me using the contact form on my website.

Licenses are for a single user. Only the buyer can use the downloaded files, please refrain from sharing or distributing them in any way.